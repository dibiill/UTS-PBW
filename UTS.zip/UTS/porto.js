document.addEventListener("DOMContentLoaded", () => {
    window.addEventListener("scroll", () => 
        document.querySelector(".navbar").classList.toggle("scrolled", window.scrollY > 50)
    );

    document.querySelectorAll(".navbar-nav .nav-link").forEach(link => 
        link.addEventListener("click", function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute("href"));
            window.scrollTo({
                top: target.offsetTop - 40,
                behavior: "smooth"
            });
        })
    );

    window.goHome = () => window.scrollTo({ top: 0, behavior: "smooth" });
});
